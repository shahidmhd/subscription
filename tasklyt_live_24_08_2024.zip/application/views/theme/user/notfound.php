<div class="row clearfix">
	<div class="col-lg-12 col-md-12">
		<div class="card planned_task">
			<div class="header text-center">
				<h2>Nothing found!</h2>
			</div>
		</div>
	</div>
</div>
