<!-- VENDOR CSS -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/font-awesome/css/font-awesome.min.css">

<!-- MAIN CSS -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/common/css/main.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/common/css/color_skins.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/common/css/custom.css">

<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<script type="text/javascript" src="<?php echo base_url();?>assets/common/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/common/js/jquery.validate.min.js"></script>
<script type="text/javascript">
var base_url = '<?php echo base_url();?>';
</script>